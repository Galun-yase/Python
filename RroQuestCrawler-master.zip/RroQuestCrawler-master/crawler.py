#-*- coding:utf-8 -*-
import os
import re
import time
import json
import requests
import logging
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException

logging.basicConfig(format="%(asctime)s-[%(levelname)s]:%(message)s",level=logging.INFO)

WORKPLACE,FILENAME=os.path.split(os.path.abspath(__file__))

urlClassify="http://www.pqdtcn.com/classify"
urlBase="http://www.pqdtcn.com"

outputCode="utf-8"
outputPath="./result.csv"
delaySeconds=5
headless=False
targets=["Pollen"]


def delay(s=5):
    global delaySeconds
    logging.info("Sleep {}s...".format(s))
    time.sleep(s)
    

def chromeInit():
    global headless
    options=webdriver.ChromeOptions()
    options._binary_location=WORKPLACE+"/Application/chrome.exe"
    options.add_argument("--disable-gpu")
    options.add_argument("--allow-running-insecure-content")
    options.add_argument("--disable-extensions")
    if headless:
        options.add_argument("--headless")
    chrome=webdriver.Chrome(options=options,executable_path=WORKPLACE+"/chromedriver.exe")
    return chrome


def outputSave(data):
    global outputCode,outputPath
    with open(outputPath,"w+",encoding=outputCode) as f:
        f.write("学科,标题,作者,页数,出版日期,学校代码,大学/机构,来源,出版地,出版国家/地区,ISBN,导师,委员会成员,学位,语言,RroQuest文档ID,文档URL,摘要\n")
        logging.info("Output File init complete:{}.".format(outputPath))
        for line in data:
            f.write(','.join(line))
    logging.info("Data saved.")

def loadConfig(path="./config.json"):
    global outputCode,outputPath,targets,headless
    try:
        with open(path,"r+",encoding="utf-8") as f:
            data=json.load(f)
            outputCode=data.get("output_file_code","utf-8")
            outputPath=data.get("output_file_path","./result.csv")
            targets=data.get("target",["Pollen"])
            headless=data.get("headless",False)
            logging.info("Load config :")
    except FileNotFoundError:
        logging.warning("Can not load config from {}".format(path))
        logging.info("Run with default config:")
    finally:
        print("    --{}:{}".format("Output Path",outputPath))
        print("    --{}:{}".format("Output code",outputCode))
        print("    --{}:{}".format("headless",headless))
        print("    --{}:{}".format("Targets",','.join(targets)))
        return

if __name__=="__main__":
    loadConfig()
    try:
        chrome=chromeInit()
        logging.info("Init complete.")
        chrome.get(urlClassify)
        logging.info("Getting the url:{}".format(urlClassify))
        delay()

        for target in targets:
            element=chrome.find_element_by_xpath("//li[text()='{}']".format(target))
            h5=element.get_attribute('outerHTML')
            chrome.execute_script("searchThesisInfo(1,'{}')".format(h5))
            logging.info("add target:{}".format(target))
            delay(2)

        element=chrome.find_element_by_xpath("""//*[@id="subject_search_params"]/button""")
        element.click()
        logging.info("Searching...")
        delay()
        element=chrome.find_element_by_xpath("""//*[@id="searchPageSize"]""")
        select=Select(element)
        select.select_by_value("50")
        logging.info("Change Num to 50")
        delay()
        textNum=chrome.find_element_by_xpath("""//*[@id="layui-laypage-2"]/span[1]""").get_attribute("innerHTML")
        totalNum=int(re.findall(r"\d+",textNum)[0])
        logging.info("Total Num:{}".format(totalNum))
        pageNum=totalNum//50 if totalNum%50==0 else totalNum//50+1
        logging.info("Total page num:{}".format(pageNum))
        
        linklist=[]
        for i in range(pageNum):
        # for i in range(1):
            elements=chrome.find_elements_by_xpath("""//*[@id="basic_search"]/table/tbody/tr[1]/td/a""")
            # print(len(elements))
            for element in elements:
                text=element.get_attribute("href")
                logging.info("Collect link:{}".format(text))
                linklist.append(text)

            if i<pageNum-1:
                logging.info("Change to page{}".format(i+2))
                buttonNext=chrome.find_element_by_class_name("layui-laypage-next")
                chrome.execute_script("arguments[0].click();",buttonNext)
                delay()

        delay()
        logging.info("Generate linklist complete.")
    except NoSuchElementException as e:
        logging.warning("Cannot found target element!")
    finally:
        delay()
        chrome.quit()
        logging.warning("Chrome quit!")


    try:
        session=requests.Session()
        session.headers.update({"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"})

        output=[]
        for i,link in enumerate(linklist):
            logging.info("Getting link [{}/{}]:{}".format(i+1,totalNum,link))
            r=session.get(link)
            soup=BeautifulSoup(r.text,"html.parser")
            divs=soup.findAll("div",attrs={"class":"display_record_indexing_data"})
            data=['"'+div.get_text().strip().replace("\n","")+'"' for div in divs]
            data.append('"'+soup.find("span",attrs={"style":"color: black;"}).get_text()+'"\n')
            output.append(data)
            # delay(0.5)
    except Exception as e:
        logging.warning("Program stop...")
        print(e)
    finally:
        outputSave(output)




