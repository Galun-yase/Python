# ProQuest Crawler

>### 简介

* ProQuest 学位论文全文检索平台爬虫。用于爬取论文简介概述等相关内容

>### 依赖

* python 3.5+
* requests
* selenium
* beautifulsoup4
* chromedriver.exe
* chrome

>### 开始

1. >安装相关依赖
    ```
    pip install -r requirements.txt
    ```
1. >配置配置文件

    打开config.json（文件默认编码为utf-8，json语法格式）编辑相关参数
    ```
    {
        "headless":true,
        "output_file_code":"utf-8",       
        "output_file_path":"./result.csv",
        "targets":["Pollen"]
    }
    ```
    参数|作用
    :---:|:---
    headless|是否开启Chrome Gui显示（即无头模式）
    output_file_code|输出文件编码格式。推荐使用utf-8，其他编码格式会在保存时出现错误。
    output_file_path|输出文件路径以及名称，输出格式为csv文件
    targets|需要爬取的目标类别 

1. >运行
    ```
    python crawler.py
    ```

>### 注意


* **本程序不支持中断重爬**

>### 替换Chrome版本
1. 下载对应的chromedriver以及chrome。
1. 将chromedriver放在脚本同级目录下
1. 将chrome安装目录可执行文件Application文件夹放在脚本同级目录内